## Example bot from Rest APIs
<a href="https://danzzapi.xyz">danzzapi.xyz</a>

## Please enter apikey in set.js
Not have apikey? Open: https://danzzapi.xyz

## Intalasi
### For termux

```
> apt update && apt upgrade
> pkg install git
> pkg install nodejs
> pkg install ffmpeg
> pkg install imagemagick
> pkg install libwebp
> pkg install yarn
> cd /sdcard
> cd GansV6
> yarn
> npm start
```

## For windows/RDP

* Download And Install Git [`Click Here`](https://git-scm.com/downloads)
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download)
* Download And Install Ffmpeg [`Click Here`](https://ffmpeg.org/download.html)

```
> cd GansV6
> npm i
> npm start
```

## Features list
* Downloader
* Asupan
* Cecan
* Cogan
* Anime
* Search
* Text pro
* Photo oxy
* Ephoto
* convert
* Other
* Owner

## Social media
<a href="https://youtube.com/@survivofc">Youtube</a><br>
<a href="https://instagram.com/b4c00t.dtz">Instagram</a><br>

## Contact
<a href="https://wa.me/6282299284898">WhatsApp</a><br>
<a href="botdeff4@gmail.com">Email</a>
